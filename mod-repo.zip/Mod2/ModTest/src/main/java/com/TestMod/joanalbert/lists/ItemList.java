package com.TestMod.joanalbert.lists;

import net.minecraft.item.Item;

public class ItemList {

	public static Item tutorial_item;
		
}
